from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route("/profile", methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':
        # Get data from the form's 'name' attributes
        user_name = request.form.get('name')
        user_age = request.form.get('age')
        user_course = request.form.get('course')
        
        # Render the template with the data received from the form
        return render_template(
            "profile.html",
            name=user_name,
            age=user_age,
            course=user_course
        )
    
    # Optional: Logic for when someone visits /profile directly via GET
    return render_template("profile.html")

@app.route("/courses")
def courses():
    course_list = ["Flask", "Django", "FastAPI"]
    return render_template("courses.html", courses=course_list)

@app.route("/student")
def student():
    data = {"name": "Shivam", "course": "Flask"}
    return render_template("student.html", student=data)

@app.route("/login-status")
def login_status():
    return render_template("status.html", is_logged_in=True)

if __name__ == "__main__":
    app.run(debug=True)
